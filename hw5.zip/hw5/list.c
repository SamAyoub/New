/***************************************************************
                                Name: Laleh Emileh
                                Class: CSE12, Winter
                                February 5th, 2019
                                login: cs12xax
                                 Assignment Five

File Name:	list.c
Description:    a polymorphic generic container based on a
linked-list data structure. In list.c, the List and Node structs
are defined. The List object contains data fields such as
occupancy and list_count, and also contains pointers to functions
which manipulate the objects stored in the list. The Node objects
form a doubly-linked list, where the pre pointer points to the
previous item in the list and the next pointer points to the next
item in the list. The list is circular, so the next pointer of
the last item points to the first item of the list, and the pre
pointer of the first item points to the last item in the list. We
keep track of the front item in the list with the front data
field of List.
*****************************************************************/
#include <malloc/malloc.h>
#include <stdio.h>
#include "mylib.h"
#include "list.h"

typedef struct Node
{
        struct Node *pre;  /* how to access the prior Node */
        struct Node *next; /* how to access the next Node */
        void *data;        /* the data to store */
} Node;

typedef struct List
{
        Node *front;     /* the front of the list */
        long list_count; /* which list is it */
        long occupancy;
        void *(*copy_func)(void *);
        void (*delete_func)(void *);
        long (*is_greater_than_func)(void *, void *);
        FILE *(*write_func)(void *, FILE *);
} List;

/* private Node function declarations */
static void delete_Node(Node **, void (*delete_func)(void *));
static Node *insert_Node(Node *, void *, void *(*copy_func)(void *));
static int locate(List *this_list, void *element);
static Node *new_Node(void *, void *(*copy_func)(void *));
static void *remove_Node(Node *);
static void *view_Node(Node *);
static FILE *write_Node(Node *, FILE *, FILE *(*write_func)(void *, FILE *));

/* catastrophic error messages */
static const char ADNEXT_NONEXIST[] =
    "Advance next from non-existent list!!!\n";
static const char ADNEXT_EMPTY[] =
    "Advance next from empty list!!!\n";
static const char ADPRE_NONEXIST[] =
    "Advance pre from non-existent list!!!\n";
static const char ADPRE_EMPTY[] =
    "Advance pre from empty list!!!\n";
static const char DELETE_NONEXIST[] =
    "Deleting from non-existent list!!!\n";
static const char DELETE_NONEXISTNODE[] =
    "Deleting a non-existent node!!!\n";
static const char ISEMPTY_NONEXIST[] =
    "Is empty check from non-existent list!!!\n";
static const char INSERT_NONEXIST[] =
    "Inserting to a non-existent list!!!\n";
static const char REMOVE_NONEXIST[] =
    "Removing from non-existent list!!!\n";
static const char REMOVE_EMPTY[] =
    "Remove from empty list!!!\n";
static const char VIEW_NONEXIST[] =
    "Viewing a non-existent list!!!\n";
static const char VIEW_NONEXISTNODE[] =
    "Viewing a non-existent node!!!\n";
static const char VIEW_EMPTY[] =
    "Viewing an empty list!!!\n";
static const char WRITE_NONEXISTFILE[] =
    "Writing to a non-existent file!!!\n";
static const char WRITE_NONEXISTLIST[] =
    "Writing from a non-existent list!!!\n";
static const char WRITE_MISSINGFUNC[] =
    "Don't know how to write out elements!!!\n";
static const char WRITE_NONEXISTNODE[] =
    "Writing from a non-existent node!!!\n";

/* debug messages */
static const char ADNEXT[] = "[List %ld - Advancing next]\n";
static const char ADPRE[] = "[List %ld - Advancing pre]\n";
static const char INSERT[] = "[List %ld - Inserting node]\n";
static const char REMOVE[] = "[List %ld - Removing node]\n";
static const char VIEW[] = "[List %ld - Viewing node]\n";
static const char LIST_ALLOCATE[] = "[List %ld has been allocated]\n";
static const char LIST_DEALLOCATE[] = "[List %ld has been deallocated]\n";

static int debug_on = FALSE;  /* allocation of debug flag */
static long list_counter = 0; /* the number of lists allocated so far */

/*--------------------------------------------------------------------------
 Function Name:         set_debug_off
 Purpose:               turns off debugging for this list
 Description:
 Input:                 void
 Result:                debug is off
                        no return type
 --------------------------------------------------------------------------*/
void set_debug_on(void)
{
        debug_on = TRUE;
}

/*--------------------------------------------------------------------------
 Function Name:         set_debug_on
 Purpose:               turns on debugging for this list
 Description:
 Input:                 void
 Result:                debug is on
                        no return type
 --------------------------------------------------------------------------*/
void set_debug_off(void)
{
        debug_on = FALSE;
}

/*--------------------------------------------------------------------------
 Function Name:         advance_next_List
 Purpose:               Calling this function causes the front pointer of
 this_list to move forward by one Node. This effectively shifts the elements of
 the list forward by one. Values of this_list are expected to be a pointer to
 the list we wish to shift.
 Description:
 Input:                 List * this_list
 Result:                no return type
 --------------------------------------------------------------------------*/
void advance_next_List(List *this_list)
{
        Node *current = this_list->front;
        Node *first;

        /* Get the last node from the list */
        while (current->pre == NULL)
        {
                first = current;
                // this_list->occupancy--;
                // insert(this_list, empty, NULL);
                insert(this_list, first, END);
                break;
        }
}

/*--------------------------------------------------------------------------
 Function Name:         advance_pre_List
 Purpose:               Calling this function causes the front pointer of
 this_list to move backward by one Node. This effectively shifts the elements of
 the list backwards by one. Values of this_list are expected to be a pointer to
 the list we wish to shift.
 Description:
 Input:                 List * this_list
 Result:                no return type
 --------------------------------------------------------------------------*/
void advance_pre_List(List *this_list)
{
        Node *last;
        Node *current = this_list->front;
        Node *first;
        Node *empty = new_Node(NULL, NULL);

        /* Get the last node from the list */
        while (current != NULL)
        {
                if (current->next == NULL)
                {
                        last = current->data;
                        //this_list->occupancy--;
                        // insert(this_list, empty, NULL);
                        insert(this_list, last, FRONT);
                        break;
                }
                current = current->next;
        }
}

/*--------------------------------------------------------------------------
 Function Name:         delete_List
 Purpose:               This destructor function deallocates all memory
 associated with the list, including the memory associated with all of the nodes
 in the list. It sets the list pointer in the calling function to NULL. Values
 of lpp are expected to be a double pointer to the list that is to be deleted.
 Description:
 Input:                 List **lpp
 Result:                delete list
                        no return type
 --------------------------------------------------------------------------*/
void delete_List(List **lpp)
{
        /* YOUR CODE GOES HERE */
}

/*--------------------------------------------------------------------------
 Function Name:         insert
 Purpose:               Inserts the element into this_list either at the front,
 end or in sorted form. locate should be used to locate where the node should go
 in the list. This function should then call insert_Node to incorporate the Node
 into the list.
 Description:
 Input:                 List * this_list, void * element, long where
 Result:
                        return 1 if successful, 0 otherwise
 --------------------------------------------------------------------------*/
long insert(List *this_list, void *element, long where)
{
        Node *node = new_Node(element, END);
        this_list->occupancy = this_list->occupancy + 1;

        {
                if (where == 0 || where == END) /* if where is zero means add for the end or last */
                {
                        /* save the current  as the front node of the list*/
                        Node *current = this_list->front;
                        /* Make the new node and save it in temp_node*/
                        Node *temp_node = new_Node(element, NULL);

                        if (current == NULL)
                        {
                                this_list->front = temp_node;
                        }
                        else
                        {
                                while (current != NULL)
                                {
                                        if (current->next == NULL)
                                        {
                                                current->next = temp_node;
                                                break;
                                        }
                                        else
                                        {
                                                current = current->next;
                                        }
                                }
                        }
                }
                else if (where == 1 || where == FRONT) /* if where is one means add for the front or first */
                {
                        /* save the current  as the front node of the list*/
                        Node *current = this_list->front;
                        /* Make the new node and save it in temp_node*/
                        Node *temp_node = new_Node(element, NULL);

                        /*For the 1st element*/
                        if (current == NULL)
                        {
                                this_list->front = temp_node;
                        }
                        else
                        {
                                while (current != NULL)
                                {
                                        if (current->pre == NULL)
                                        {
                                                temp_node->next = current;
                                                this_list->front = temp_node;
                                                break;
                                        }
                                        else
                                        {
                                                current = current->next;
                                        }
                                }
                        }
                }
                /* if where is two means add for the front or first */
                else if (where == 2)
                {
                }
        }
        return 1;
}

/*
locate:
locate should be used to locate where the node should be in a sorted list. If
your implementation of locate changes the front pointer of the list, be sure to
save that value before calling this function. Note: you have the flexibility to
change the signature of this function to have a different return value or
parameters.
Values of this_list are expected to be a pointer to the list we wish to check.
Values of element are expected to be a pointer to the object we wish to insert
in the list. Result is expected to be true inserting at the front of the list.
*/
static int locate(List *this_list, void *element)
{
        return (this_list->front == NULL);
}

/*--------------------------------------------------------------------------
 Function Name:         isempty_List
 Purpose:               Checks to see if this_list is empty.
Values of this_list are expected to be a pointer to the list we wish to check.
 Description:
 Input:                 List * this_list
 Result:                Front is empty
 --------------------------------------------------------------------------*/
long isempty_List(List *this_list)
{
        return (this_list->front == NULL);
}

/*--------------------------------------------------------------------------
 Function Name:         new_List
 Purpose:               This constructor function allocates and initializes a
 new List object. It initializes the list data fields, and returns a pointer to
 the list. All new lists should be empty. Values of copy_func are expected to be
 a pointer to the function which makes copies of the elements stored in
 this_list. Values of delete_func are expected to be a pointer to the function
 which frees the memory associated with elements stored in this_list. Values of
 is_greater_than_func are expected to be a pointer to the function which
 compares elements in this_list. Values of write_func are expected to be a
 pointer to the function which writes elements in this_list.
 Description:
 Input:                 void * (*copy_func)
                        void   (*delete_func)
                        long (*is_greater_than_func)
                        FILE * (*write_func)
 Result:                return pointer to the list
 --------------------------------------------------------------------------*/
List *new_List(
    void *(*copy_func)(void *),
    void (*delete_func)(void *),
    long (*is_greater_than_func)(void *, void *),
    FILE *(*write_func)(void *, FILE *))
{
        List *this_List = (List *)malloc(sizeof(List));
        if (this_List == NULL)
        {
                printf("Unable to allocate memory.\n");
                exit(0);
        }
        /* this list front = 0 */
        this_List->front = 0;
        /* Add one to the list counter */
        this_List->list_count = list_counter + 1;
        /* this list occupancy = 0 */
        this_List->occupancy = 0;
        /* Allocate this list function copy_func */
        this_List->copy_func = copy_func;
        /* Allocate this list function delete_func */
        this_List->delete_func = delete_func;
        /* Allocate this list function write_func */
        this_List->write_func = write_func;
        /* Allocate this list function is_greater_than_func */
        this_List->is_greater_than_func = is_greater_than_func;
        /* Return the new list*/
        return this_List;
}

/*--------------------------------------------------------------------------
 Function Name:         remove_List
 Purpose:               Removes an element in this_list at location where. This
 function should call remove_Node to restructure the list to remove the node.
 Values of this_list are expected to be a pointer to the list from which we wish
 to remove. Values of where are expected the place in the number of the element
 in the list we wish to remove insert (1 for first item, 0 for last item).
 Description:
 Input:                 List * this_list, long where
 Result:                return a pointer to the removed node's data
 --------------------------------------------------------------------------*/
void *remove_List(List *this_list, long where)
{
        /* YOUR CODE GOES HERE */
}

/*--------------------------------------------------------------------------
 Function Name:         view
 Purpose:               Returns a pointer to the object stored at location where
 for viewing. This function should call view_Node, which returns the data.
 Values of this_list are expected to be a pointer to the list we wish to check.
 Values of where are expected the place in the list which holds the element to
 view (1 for first item, 0 for last item).
 Description:
 Input:                 List * this_list, long where
 Result:                returns a pointer to the object stored at location
                        where for viewing
 --------------------------------------------------------------------------*/
void *view(List *this_list, long where)
{
        return this_list->occupancy;
}

/*--------------------------------------------------------------------------
 Function Name:         write_List
 Purpose:               check if stream and this_list exist, otherwise print
                        out error messages. Also check if stream equals to
                        stderr, !this_list -> write_func, and this_list ->
                        occupancy >= 1
 Description:
 Input:                 List * this_list, FILE * stream
 Result:                return stream
 --------------------------------------------------------------------------*/
FILE *write_List(List *this_list, FILE *stream)
{
        long count;    /* to know how many elements to print */
        Node *working; /* working node */

        if (!stream)
        {
                fprintf(stderr, WRITE_NONEXISTFILE);
                return NULL;
        }

        if (!this_list)
        {
                fprintf(stderr, WRITE_NONEXISTLIST);
                return NULL;
        }

        if (stream == stderr)
                fprintf(stream, "List %ld has %ld items in it.\n",
                        this_list->list_count, this_list->occupancy);

        if (!this_list->write_func)
        {
                fprintf(stream, WRITE_MISSINGFUNC);
                return stream;
        }

        if (this_list->occupancy >= 1)
                working = this_list->front;

        for (count = 1; count <= this_list->occupancy; count++)
        {
                if (stream == stderr)
                        fprintf(stream, "\nelement %ld:  ", count);
                write_Node(working, stream, this_list->write_func);
                working = working->next;
        }

        return stream;
}

/*--------------------------------------------------------------------------
 Function Name:         write_reverse_List
 Purpose:               Writes the elements of this_list backwards, starting
 with the last item. The list is printed to filestream stream. Values of
 this_list are expected to be a pointer to the list we wish to write. Values of
 stream are expected to be either stdout or stderr.
 Description:
 Input:                 List * this_list, FILE * stream
 Result:
 --------------------------------------------------------------------------*/
FILE *write_reverse_List(List *this_list, FILE *stream)
{
        long count;  /* to know how many elements to print */
        Node *exits; /* exits node */
        Node *current = this_list->front;
        Node *prev = NULL;
        Node *next = NULL;

        if (!stream)
        {
                fprintf(stderr, WRITE_NONEXISTFILE);
                return NULL;
        }

        if (!this_list)
        {
                fprintf(stderr, WRITE_NONEXISTLIST);
                return NULL;
        }

        if (stream == stderr)
                fprintf(stream, "List %ld has %ld items in it.\n",
                        this_list->list_count, this_list->occupancy);

        if (!this_list->write_func)
        {
                fprintf(stream, WRITE_MISSINGFUNC);
                return stream;
        }

        if (this_list->occupancy >= 1)

                while (current != NULL)
                {
                        next = current->next;
                        current->next = prev;
                        prev = current;
                        current = next;
                }
        current = prev;
        exits = current;

        for (count = 1; count <= this_list->occupancy; count++)
        {
                if (stream == stderr)
                        fprintf(stream, "\nelement %ld:  ", count);
                write_Node(exits, stream, this_list->write_func);
                exits = exits->next;
        }

        return stream;
}

/*--------------------------------------------------------------------------
 Function Name:         delete_Node
 Description:           Delete node if exist
 Input:                 Node ** npp
                        void (*delete_func)
 Result:                no return type
 --------------------------------------------------------------------------*/
static void delete_Node(Node **npp, void (*delete_func)(void *))
{

        /* does the node exist??? */
        if (!npp || !*npp)
        {
                fprintf(stderr, DELETE_NONEXISTNODE);
                return;
        }

        /* call function to delete element */
        if (delete_func && (*npp)->data)
                (*delete_func)(&((*npp)->data));

        /* delete element */
        free(*npp);

        /* assign node to NULL */
        *npp = NULL;
}

/*--------------------------------------------------------------------------
 Function Name:         insert_Node
 Purpose:               Creates a new node to hold element, or, if copy_func is
 non-NULL, a copy of element. This new node is then incorporated into the list
 at the location BEFORE this_Node. Values of this_Node are expected to be a
 pointer to the Node that the new node is inserted BEFORE. Values of element are
 expected to be a pointer to the object we wish to store in the new node. Values
 of copy_func are expected to be the pointer to the copy function passed into
 the list constructor or NULL if no copy needs to be made.
 Description:
 Input:                 Node * this_Node
                        void * element
                        void * (*copy_func)
 Result:                re
 --------------------------------------------------------------------------*/
static Node *insert_Node(Node *this_Node, void *element,
                         void *(*copy_func)(void *))
{
        /* Create new node */
        Node *new_node = new_Node(element, copy_func);
        /* check if the given this_Node is NULL */
        if ((new_node == NULL || this_Node == NULL) && debug_on)
        {
                printf("Unable to allocate memory.");
                return 0;
        }
        else
        {
                this_Node->data = new_node->data; // Link data part
                this_Node->next = new_node->next; // Link address part
                this_Node->pre = new_node->pre;   // Link address part

                this_Node = new_node; // Make newNode as first node
        }

        return this_Node;
}

/*--------------------------------------------------------------------------
 Function Name:         new_Node
 Description:           call malloc to allocate new node.
 Input:                 void * element
                        void * (*copy_func)
 Result:                return this_Node
 --------------------------------------------------------------------------*/
static Node *new_Node(void *element, void *(*copy_func)(void *))
{

        /* allocate memory */
        Node *this_Node = (Node *)malloc(sizeof(Node));

        /* initialize memory */
        this_Node->next = this_Node->pre = NULL;
        this_Node->data = (copy_func) ? (*copy_func)(element) : element;

        return this_Node;
}

/*--------------------------------------------------------------------------
 Function Name:         remove_Node
 Purpose:              "Unlinks" this_Node from the list by arranging the
 pointers of the surrounding Nodes so they no longer point to this_Node. The
 memory associated with the Node object is freed, but the Node's data is not
 deleted. A pointer to the data is returned. Values of this_Node are expected to
 be a pointer to the Node we wish to remove from the list.
 Description:
 Input:                 List * this_list
 Result:                return pointer to data
 --------------------------------------------------------------------------*/
static void *remove_Node(Node *this_Node)
{
        if (this_Node->data == NULL)
        {
                printf("The node can't be made empty ");
        }

        return this_Node;
}

/*--------------------------------------------------------------------------
 Function Name:         view_Node
 Purpose:               Returns a pointer to this_Node's data. Values of
 this_Node are expected to be a pointer to the Node whose data we wish to view.
 Input:                 Node * this_Node
 Result:                returns a pointer to this_Node's data
 --------------------------------------------------------------------------*/
static void *view_Node(Node *this_Node)
{
        while (this_Node != NULL)
        {
                printf(" %d ", this_Node->data);
                this_Node = this_Node->next;
        }
}

/*--------------------------------------------------------------------------
 Function Name:         write_Node
 Description:           write messages
 Result:                return (*write_func) (this_Node->data, stream)
 --------------------------------------------------------------------------*/
static FILE *write_Node(Node *this_Node, FILE *stream,
                        FILE *(*write_func)(void *, FILE *))
{

        if (!stream)
        {
                fprintf(stderr, WRITE_NONEXISTFILE);
                return NULL;
        }

        if (!this_Node)
        {
                fprintf(stream, WRITE_NONEXISTNODE);
                return stream;
        }

        if (!write_func)
        {
                fprintf(stream, WRITE_MISSINGFUNC);
                return stream;
        }

        return (*write_func)(this_Node->data, stream);
}
